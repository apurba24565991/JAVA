import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyFrame extends JFrame implements ActionListener
{

	private JLabel titleLabel,imgLabel, studentIdLbl,passLabel,nameLbl,dateOfBirthLbl,ageLbl, phoneNumberLbl, emailIdLbl,fathersNameLabel,mothersNameLabel,fatherssNumberLabel,mothersNumberLabel,addressLbl,genderLabel,bloodGrpLabel,allergiesLabel,subjectLabel,clubLabel;
	private JTextField idTF,nameTF,dateOfBirtTF,ageTF,phoneTF,emailIdTF,addressTF,fathersNameTF,mothersNameTF ,fathersNumberTF,mothersNumberTF;
	private JPasswordField passPF;
	private JButton submit, exit;
	private JRadioButton yesRB,noRB,maleRB,femaleRB;
	private JCheckBox cb1, cb2, cb3;
	private JComboBox subjectChoice, bloodGroup;
	private ButtonGroup btng;
	private JPanel panel;
	private Color color1,color2;
	private Font font1;
	private ImageIcon img;
	private ImageIcon backImg;	
		
	
	public MyFrame()
	{
		super("Student Registration System");
		this.setSize(1200,1000);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.backImg=new ImageIcon("image/AIUB.png");
		
		this.panel= new JPanel()
		{
			protected void paintComponent(Graphics g)
			{
				super.paintComponent(g);
				g.drawImage(backImg.getImage(),955,10,null);
			}
		};
		
		
	    this.font1=new Font("Cambria", Font.BOLD,30);
		this.panel.setLayout(null);
		this.panel.setBackground(Color.WHITE);
	
		
		this.titleLabel=new JLabel("AMERICAN INTERNATIONAL UNIVERSITY - BANGLADESH");
		this.titleLabel.setBounds(150,50,800,30);
	    this.titleLabel.setBackground(Color.WHITE);
		this.titleLabel.setFont(font1);
		this.panel.add(titleLabel);
		
		
		this.studentIdLbl=new JLabel("Student Id:");
		this.studentIdLbl.setBounds(100,100,100,20);
		this.panel.add(studentIdLbl);
		
		this.idTF=new JTextField();
		this.idTF.setBounds(200,100,100,30);
		this.panel.add(idTF);
		
		
		this.passLabel=new JLabel("Password:");
		this.passLabel.setBounds(350,100,100,30);
		this.panel.add(passLabel);
		
		this.passPF=new JPasswordField();
		this.passPF.setBounds(450,100,100,30);
		this.panel.add(passPF);
		
		
		this.nameLbl=new JLabel("Name :");
		this.nameLbl.setBounds(100,150,50,20);
		this.panel.add(nameLbl);
		
		this.nameTF=new JTextField();
		this.nameTF.setBounds(200,150,350,30);
		this.panel.add(nameTF);
		
		this.dateOfBirthLbl=new JLabel("Date Of Birth:");
		this.dateOfBirthLbl.setBounds(100,200,150,20);
		this.panel.add(dateOfBirthLbl);
		
		this.dateOfBirtTF=new JTextField();
		this.dateOfBirtTF.setBounds(350,200,65,30);
		this.panel.add(dateOfBirtTF);
		
		
		this.ageLbl=new JLabel("Age:");
		this.ageLbl.setBounds(300,200,50,20);
		this.panel.add(ageLbl);
		
		this.ageTF=new JTextField();
		this.ageTF.setBounds(200,200,70,30);
		this.panel.add(ageTF);
		
		
		
		this.phoneNumberLbl=new JLabel("Phone No:");
		this.phoneNumberLbl.setBounds(450,200,100,20);
		this.panel.add(phoneNumberLbl);
		
		this.phoneTF=new JTextField();
		this.phoneTF.setBounds(550,200,150,30);
		this.panel.add(phoneTF);
		
		
		this.emailIdLbl=new JLabel("E-mail ID:");
		this.emailIdLbl.setBounds(730,200,100,20);
		this.panel.add(emailIdLbl);
		
		this.emailIdTF=new JTextField();
		this.emailIdTF.setBounds(830,200,220,30);
		this.panel.add(emailIdTF);
		
		
		this.fathersNameLabel=new JLabel("Father's Name:");
		this.fathersNameLabel.setBounds(100,250,200,20);
		this.panel.add(fathersNameLabel);
		
		this.fathersNameTF=new JTextField();
		this.fathersNameTF.setBounds(200,250,250,30);
		this.panel.add(fathersNameTF);
		
		
		this.mothersNameLabel=new JLabel("Mother's Name:");
		this.mothersNameLabel.setBounds(500,250,200,20);
		this.panel.add(mothersNameLabel);
		
		this.mothersNameTF=new JTextField();
		this.mothersNameTF.setBounds(600,250,250,30);
		this.panel.add(mothersNameTF);
		
		
		this.fatherssNumberLabel=new JLabel("Father's Number:");
		this.fatherssNumberLabel.setBounds(100,300,200,20);
		this.panel.add(fatherssNumberLabel);
		
		this.fathersNumberTF=new JTextField();
		this.fathersNumberTF.setBounds(200,300,200,25);
		this.panel.add(fathersNumberTF);
		
		
		this.mothersNumberLabel=new JLabel("Mother's Number:");
		this.mothersNumberLabel.setBounds(450,300,200,20);
		this.panel.add(mothersNumberLabel);
		
		this.mothersNumberTF=new JTextField();
		this.mothersNumberTF.setBounds(560,300,200,25);
		this.panel.add(mothersNumberTF);
		
		
		this.addressLbl=new JLabel("Address :");
		this.addressLbl.setBounds(100,330,70,20);
		this.panel.add(addressLbl);
		
		this.addressTF=new JTextField();
		this.addressTF.setBounds(200,330,350,30);
		this.panel.add(addressTF);
		
		
		this.genderLabel=new JLabel("Gender:");
		this.genderLabel.setBounds(100,380,200,20);
		this.panel.add(genderLabel);
		
		this.maleRB=new JRadioButton("Male");
		this.maleRB.setBounds(320,380,80,20);
		this.panel.add(maleRB);
		
		this.femaleRB=new JRadioButton("Female");
		this.femaleRB.setBounds(200,380,100,20);
		this.panel.add(femaleRB);
		
		this.btng=new ButtonGroup();
		this.btng.add(maleRB);
		this.btng.add(femaleRB);
		
		this.bloodGrpLabel=new JLabel("Select your Blood Group:");
		this.bloodGrpLabel.setBounds(100,430,250,20);
		this.panel.add(bloodGrpLabel);
		
		String data2[]={"Select","A+","B+","A-","B-","AB+","AB-","O+","O-"};
		
		this.bloodGroup=new JComboBox(data2);
		this.bloodGroup.setBounds(300,430,100,30);
		this.panel.add(bloodGroup);
		
		this.allergiesLabel=new JLabel("Do you have any allergies?");
		this.allergiesLabel.setBounds(500,430,200,20);
		this.panel.add(allergiesLabel);
		
	    this.yesRB=new JRadioButton("Yes");
		this.yesRB.setBounds(710,430,50,20);
		this.panel.add(yesRB);
		
		this.noRB=new JRadioButton("No");
		this.noRB.setBounds(780,430,50,20);
		this.panel.add(noRB);
		
		this.btng=new ButtonGroup();
		this.btng.add(yesRB);
		this.btng.add(noRB);
		
		
		this.subjectLabel=new JLabel("Which Subject you want to apply?");
		this.subjectLabel.setBounds(100,480,200,20);
		this.panel.add(subjectLabel);
		
		String data[]={"Choose","CSE","EEE","BUSINESS","HUMANITIES","PSYCOLOGY","ENGLISH"};
		
		this.subjectChoice=new JComboBox(data);
		this.subjectChoice.setBounds(300,480,100,30);
		this.panel.add(subjectChoice);
		
		
		this.clubLabel=new JLabel("Which Club would you like to join?");
		this.clubLabel.setBounds(100,530,200,20);
		this.panel.add(clubLabel);
		
		this.cb1=new JCheckBox("English Club");
		this.cb1.setBounds(500,530,100,20);
		this.panel.add(cb1);
		
		this.cb2=new JCheckBox("Robotics Club");
		this.cb2.setBounds(300,530,120,20);
		this.panel.add(cb2);
		
		this.cb3=new JCheckBox("Sports Club");
		this.cb3.setBounds(700,530,100,20);
		this.panel.add(cb3);
		
		
		this.submit=new JButton("Submit");
		this.submit.setBounds(200,600,80,30);
		this.submit.addActionListener(this);
		this.panel.add(submit);
		
		
		this.exit=new JButton("Exit");
		this.exit.setBounds(550,600,80,30);
		this.exit.addActionListener(this);
		this.panel.add(exit);
		
		
		
		this.add(panel);
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command= ae.getActionCommand();
		if(exit.getText().equals(command))
		{
			System.exit(0);
		}
		
		if(submit.getText().equals(command))
		{
			JOptionPane.showMessageDialog(this, "     Deatils Submitted.\n Click OK to see results.");
		}


		if(submit.getText().equals(command))
		{
			
			String name="",id="",phone="",age="",dateOfBirth="",emailID="",address="",fathersName="",mothersName="",fathersNumber="",mothersNumber="", password="",gender="",allergies="",subject="",bldGroup="",clubs="";
			
		
			if((!idTF.getText().isEmpty())&&(!fathersNameTF.getText().isEmpty())&&(!mothersNameTF.getText().isEmpty())&&(!fathersNumberTF.getText().isEmpty())&&(!mothersNumberTF.getText().isEmpty()) && (!passPF.getText().isEmpty()) &&(!nameTF.getText().isEmpty())&& (!ageTF.getText().isEmpty())&&(!addressTF.getText().isEmpty()) &&(!dateOfBirtTF.getText().isEmpty() )&& (!phoneTF.getText().isEmpty()) &&(!emailIdTF.getText().isEmpty() )&& (maleRB.isSelected() || femaleRB.isSelected()) &&(yesRB.isSelected() || noRB.isSelected())) 
			{

				name=nameTF.getText();
				id=idTF.getText();
				password=passPF.getText();
				phone=phoneTF.getText();
				age=ageTF.getText();
				dateOfBirth=dateOfBirtTF.getText();
				emailID=emailIdTF.getText();
				address=addressTF.getText();
				fathersName=fathersNameTF.getText();
				mothersName=mothersNameTF.getText();
				fathersNumber=fathersNumberTF.getText();
				mothersNumber=mothersNumberTF.getText();
				password=passPF.getText();
				
								
			    if (maleRB.isSelected()) 
		        {
                gender = maleRB.getText();
                } 
			    else
			    {
                gender = femaleRB.getText();
			    }

                if (yesRB.isSelected()) 
			    {
                allergies = yesRB.getText();
                } 
			    else 
			    {
                allergies = noRB.getText();
                }
            
			    if(cb1.isSelected())
				{
					clubs=cb1.getText();
				}
				
				if(cb2.isSelected())
				{
					clubs=clubs+cb2.getText();
				}
				
				if(cb3.isSelected())
				{
					clubs=clubs+cb3.getText();
				}
				
            subject = subjectChoice.getSelectedItem().toString();
		    bldGroup= bloodGroup.getSelectedItem().toString();

				
			MyDataFrame mdf=new MyDataFrame(name,id,phone,dateOfBirth,age,emailID,address,fathersName,mothersName,fathersNumber,mothersNumber, password,gender,allergies,subject,bldGroup,clubs);
			this.setVisible(false);
			mdf.setVisible(true);
			}
			
			else
			{
				JOptionPane.showMessageDialog(this,"Please Fill up all the field");
			}
		}
	}
}

	