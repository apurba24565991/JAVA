import java.lang.*;
import javax.swing.*;

public class MyDataFrame extends JFrame 
{
    private JTable myData;
    private JScrollPane myDataScrollPane;
    private JPanel panel;

    
    public MyDataFrame(String name, String id, String phone, String age, String dateOfBirth, String emailID,String address, String fathersName, String mothersName, String fathersNumber,String mothersNumber, String password, String gender, String allergies,String subject, String bldGroup, String clubs) 
	{
        super("Registered Successfully");
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.panel = new JPanel();
        this.panel.setLayout(null);
		

		String headData[] = new String[2] ;
		headData[0]="Type";
		headData[1]="Data";
		

        String tableData[][] =new String [17][2];
		tableData[0][0]="Student ID";
		tableData[0][1]=id;
		
		tableData[1][0]="Password";
		tableData[1][1]=password;
		
		tableData[2][0]="Name";
		tableData[2][1]=name;
		
		tableData[3][0]="Date of Birth";
		tableData[3][1]=dateOfBirth;
		
		tableData[4][0]="Age";
		tableData[4][1]=age;
		
		tableData[5][0]="Phone number";
		tableData[5][1]=phone;
		
		tableData[6][0]="Email ID";
		tableData[6][1]=emailID;
		
		tableData[7][0]="Father's Name";
		tableData[7][1]=fathersName;
		
		tableData[8][0]="Mother's Name";
		tableData[8][1]=mothersName;
		
		tableData[9][0]="Father's Number";
		tableData[9][1]=fathersNumber;
		
		tableData[10][0]="Mother's Number";
		tableData[10][1]=mothersNumber;
		
		tableData[11][0]="Address";
		tableData[11][1]=address;
		
		tableData[12][0]="Gender";
		tableData[12][1]=gender;
		
		tableData[13][0]="Blood Group";
		tableData[13][1]=bldGroup;
		
		tableData[14][0]="Allergies";
		tableData[14][1]=allergies;
		
		tableData[15][0]="Subject";
		tableData[15][1]=subject;
		
		tableData[16][0]="Clubs";
		tableData[16][1]=clubs;
		
		
        this.myData= new JTable(tableData, headData);

        this.myDataScrollPane = new JScrollPane(myData);
        this.myDataScrollPane.setBounds(20, 20, 500, 500); 
        this.panel.add(myDataScrollPane);
		
		
		this.panel.revalidate();
		this.panel.repaint();


        this.add(panel);
    }
}